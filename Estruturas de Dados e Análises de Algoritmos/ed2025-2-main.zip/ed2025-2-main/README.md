# Estrutura de Dados

Disciplina lecionada durante o segundo semestre de 2025.

## OBS: Este repositório estará disponível até o final do semestre
> As atualizações são feitas após cada aula.

Pode baixar diretamente do GitHub ( /Code/Download ZIP) ou usando o Git:

Utilize o *"git clone"* para fazer uma cópia local.
```bash
git clone <link>
```
Utilize *"git pull"* para manter sua copia local atualizada

```bash
git pull 
```
