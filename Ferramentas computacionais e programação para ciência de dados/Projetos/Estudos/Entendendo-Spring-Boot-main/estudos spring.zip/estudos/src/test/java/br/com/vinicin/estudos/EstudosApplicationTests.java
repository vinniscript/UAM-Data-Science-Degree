package br.com.vinicin.estudos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EstudosApplicationTests {

	@Test
	void contextLoads() {
	}

}
